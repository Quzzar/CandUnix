#ifndef _HEADER_H_
#define _HEADER_H_

int testNumber(int test, int max);
int inputInt();

#endif