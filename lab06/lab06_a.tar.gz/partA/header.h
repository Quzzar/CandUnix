#ifndef _HEADER_H_
#define _HEADER_H_

#define PI 3.1415926

double getVolume(double radius);
double getSurfaceArea(double radius);
double inputRadius();

#endif