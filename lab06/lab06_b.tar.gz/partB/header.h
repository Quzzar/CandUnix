#ifndef _HEADER_H_
#define _HEADER_H_

#define MIN_ASCII 32
#define MAX_ASCII 126
#define ERROR_CODE -1

int printASCII(int num);
int printRange(int min, int max);
int inputValue(int min, int max);

#endif